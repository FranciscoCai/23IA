using UnityEngine;

public class AIData_Guard : MonoBehaviour
{
}
