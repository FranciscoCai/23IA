using UnityEngine;

public class AIData_Worker : MonoBehaviour
{

}
